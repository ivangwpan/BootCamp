const mix = require('laravel-mix');

mix.sass('resources/sass/all.scss', 'public/css');
