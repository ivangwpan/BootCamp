@extends('templates.fontTemplete')
@section('style')
    <style>
        .apart{
            letter-spacing:1em;
        }
    </style>
@endsection

@section('main-content')
<div class="container">
    <div class="card">
        

    </div>







</div>

@endsection
@section('js')
    <script></script>
@endsection
