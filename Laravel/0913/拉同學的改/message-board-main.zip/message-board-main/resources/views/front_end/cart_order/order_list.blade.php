@extends('templates.fontTemplete')
@section('style')
    <style>

    </style>
@endsection
@section('main-content')


    <div class="container">
        <section class="order-header"></section>
        <section class="order-body"></section>
        <section class="order-footer"></section>




    </div>


@endsection
@section('js')
    <script>

    </script>




@endsection

